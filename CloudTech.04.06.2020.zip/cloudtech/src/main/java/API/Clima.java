package API;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.sun.el.parser.ParseException;

public class Clima {
	public Headline headline;
	public DailyForecasts dailyforecasts;
	
	public Clima() {
		
	}
	
	public Headline getHeadline() {
		return headline;
	}
	public void setHeadline(Headline headline) {
		this.headline = headline;
	}
	public DailyForecasts getDailyforecasts() {
		return dailyforecasts;
	}
	public void setDailyforecasts(DailyForecasts dailyforecasts) {
		this.dailyforecasts = dailyforecasts;
	}
		
}