package API;

import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class DailyForecasts extends Clima {
	public Temperature temperature;

	public DailyForecasts() {
		super()	;
	}
	public static void ReadJSON(Clima clima) {

        Temperature temperature = new Temperature();
        DailyForecasts dailyForecasts = new DailyForecasts();
        JSONObject jsonObject = null, tempList;
        JSONParser parser = new JSONParser();
        JSONArray  dailyFor;
        Map temp, min, max;
        Maximun maximun = new Maximun();
        Minimun minimun = new Minimun();
        double ma, mi;

        try {
            jsonObject = (JSONObject) parser.parse(new FileReader("saida.json"));
            dailyFor = (JSONArray) jsonObject.get("DailyForecasts");
            tempList = (JSONObject) dailyFor.get(0);
            temp = (Map) tempList.get("Temperature");
            min = (Map) temp.get("Minimum");
            mi = (Double) min.get("Value");
            minimun.value = Temperature.getCelsius(mi);
            max = (Map) temp.get("Maximum");
            ma = (Double) max.get("Value");
            maximun.value = Temperature.getCelsius(ma);
            
            temperature.setMaximun(maximun);
            temperature.setMinimun(minimun);
            

            dailyForecasts.setTemperature(temperature);
            clima.setDailyforecasts(dailyForecasts);

        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }


    public void setTemperature(Temperature temperature) {
        this.temperature = temperature;
    }
}
