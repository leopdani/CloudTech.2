package API;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Headline extends Clima{ 
	public String text;
	public long severity;
	
	public Headline() {
		
		
	}
	
	public static void ReadJSON(Clima clima){

        Headline headline = new Headline();
        JSONObject jsonObject;
        JSONParser parser = new JSONParser();
        Map hl;

        try {
            jsonObject = (JSONObject) parser.parse(new FileReader("saida.json"));
            hl = (Map) jsonObject.get("Headline");
            headline.text = (String) hl.get("Text");
            headline.severity = (Long) hl.get("Severity");
            

            clima.setHeadline(headline);

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

    }
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public long getSeverity() {
		return severity;
	}
	public void setSeverity(long severity) {
		this.severity = severity;
	}
	
}
