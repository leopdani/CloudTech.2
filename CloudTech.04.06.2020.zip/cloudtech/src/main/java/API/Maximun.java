package API;

public class Maximun extends Temperature{
	public double value;
	
	public Maximun() {
		super()	;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
}
