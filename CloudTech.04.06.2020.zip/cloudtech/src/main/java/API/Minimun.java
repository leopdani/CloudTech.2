package API;

public class Minimun extends Temperature{
	public double value;
	
	public Minimun() {
		super()	;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
	
}
