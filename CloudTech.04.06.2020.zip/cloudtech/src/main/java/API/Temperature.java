package API;

public class Temperature extends DailyForecasts {
	public Maximun maximun;
	public Minimun minimun;
	
	public Temperature() {
		super()	;
	}

	public void setMaximun(Maximun maximun) {
		this.maximun = maximun;
	}

	public void setMinimun(Minimun minimun) {
		this.minimun = minimun;
	}
	
	public static double getCelsius(double F){
        return (F-32.0)*(5.0/9.0);
    }
}
