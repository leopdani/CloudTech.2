package br.usjt.cloudtech.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import API.Clima;
import API.ClimaPrint;

@Controller
public class APIcontroller {


	@RequestMapping("/Teste")
	public String APIGetText(Model model, Clima clima){

		clima = ClimaPrint.clima;
		long severity = clima.headline.severity;
		String texto = clima.headline.text;
		double maximun = clima.dailyforecasts.temperature.maximun.value;
		double minimun = clima.dailyforecasts.temperature.minimun.value;
			return "Teste";
	}
}
