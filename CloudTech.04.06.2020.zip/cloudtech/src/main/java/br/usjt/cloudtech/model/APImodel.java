package br.usjt.cloudtech.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import API.Clima;
import API.ClimaPrint;


@Entity
public class APImodel extends ClimaPrint {
	
	Clima clima = ClimaPrint.clima;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long severity = ClimaPrint.clima.headline.severity;
	private String texto = ClimaPrint.clima.headline.text;
	private double maximun = ClimaPrint.clima.dailyforecasts.temperature.maximun.value;
	private double minimun = ClimaPrint.clima.dailyforecasts.temperature.minimun.value;
	public Long getSeverity() {
		return severity;
	}
	public void setSeverity(Long severity) {
		this.severity = severity;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public double getMaximun() {
		return maximun;
	}
	public void setMaximun(double maximun) {
		this.maximun = maximun;
	}
	public double getMinimun() {
		return minimun;
	}
	public void setMinimun(double minimun) {
		this.minimun = minimun;
	}
	
	
	
}
